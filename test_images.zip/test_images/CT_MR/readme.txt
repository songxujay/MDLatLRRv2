XX-1.jpg CT图像
XX-2.jpg MRI图像