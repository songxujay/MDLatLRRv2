CT_MR、MR_PET、MR_SPECT为待融合的三组医学图像，
图像数据来源：http://www.escience.cn/people/xiaomi/index.html