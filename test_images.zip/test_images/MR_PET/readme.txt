XX-1.jpg MRI图像
XX-2.jpg PET图像